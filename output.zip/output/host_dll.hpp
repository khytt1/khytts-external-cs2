// Generated using https://github.com/a2x/cs2-dumper
// 2026-02-26 02:24:39.089532300 UTC

#pragma once

#include <cstddef>
#include <cstdint>

namespace cs2_dumper {
    namespace schemas {
        // Module: host.dll
        // Class count: 2
        // Enum count: 0
        namespace host_dll {
            // Parent: None
            // Field count: 1
            namespace EmptyTestScript {
                constexpr std::ptrdiff_t m_hTest = 0x10; // CAnimScriptParam<float32>
            }
            // Parent: None
            // Field count: 1
            namespace CAnimScriptBase {
                constexpr std::ptrdiff_t m_bIsValid = 0x8; // bool
            }
        }
    }
}
