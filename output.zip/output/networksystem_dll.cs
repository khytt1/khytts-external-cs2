// Generated using https://github.com/a2x/cs2-dumper
// 2026-02-26 02:24:39.089532300 UTC

namespace CS2Dumper.Schemas {
    // Module: networksystem.dll
    // Class count: 1
    // Enum count: 1
    public static class NetworksystemDll {
        // Alignment: 4
        // Member count: 4
        public enum OutOfPVSUpdates_t : uint {
            OOPVSUpdates_OptOut = 0x0,
            OOPVSUpdates_OptIn = 0x1,
            OOPVSUpdates_Default = 0x2,
            OOPVSUpdates_Count = 0x3
        }
        // Parent: None
        // Field count: 1
        public static class ChangeAccessorFieldPathIndex_t {
            public const nint m_Value = 0x0; // int32
        }
    }
}
