// Generated using https://github.com/a2x/cs2-dumper
// 2026-02-26 02:24:39.089532300 UTC

#![allow(non_upper_case_globals, unused)]

pub mod cs2_dumper {
    // Module: client.dll
    pub mod buttons {
        pub const attack: usize = 0x205E870;
        pub const attack2: usize = 0x205E900;
        pub const back: usize = 0x205EB40;
        pub const duck: usize = 0x205EE10;
        pub const forward: usize = 0x205EAB0;
        pub const jump: usize = 0x205ED80;
        pub const left: usize = 0x205EBD0;
        pub const lookatweapon: usize = 0x2315E80;
        pub const reload: usize = 0x205E7E0;
        pub const right: usize = 0x205EC60;
        pub const showscores: usize = 0x2315D60;
        pub const sprint: usize = 0x205E750;
        pub const turnleft: usize = 0x205E990;
        pub const turnright: usize = 0x205EA20;
        pub const r#use: usize = 0x205ECF0;
        pub const zoom: usize = 0x2315DF0;
    }
}
