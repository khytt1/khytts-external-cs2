// Generated using https://github.com/a2x/cs2-dumper
// 2026-02-26 02:24:39.089532300 UTC

#pragma once

#include <cstddef>
#include <cstdint>

namespace cs2_dumper {
    // Module: client.dll
    namespace buttons {
        constexpr std::ptrdiff_t attack = 0x205E870;
        constexpr std::ptrdiff_t attack2 = 0x205E900;
        constexpr std::ptrdiff_t back = 0x205EB40;
        constexpr std::ptrdiff_t duck = 0x205EE10;
        constexpr std::ptrdiff_t forward = 0x205EAB0;
        constexpr std::ptrdiff_t jump = 0x205ED80;
        constexpr std::ptrdiff_t left = 0x205EBD0;
        constexpr std::ptrdiff_t lookatweapon = 0x2315E80;
        constexpr std::ptrdiff_t reload = 0x205E7E0;
        constexpr std::ptrdiff_t right = 0x205EC60;
        constexpr std::ptrdiff_t showscores = 0x2315D60;
        constexpr std::ptrdiff_t sprint = 0x205E750;
        constexpr std::ptrdiff_t turnleft = 0x205E990;
        constexpr std::ptrdiff_t turnright = 0x205EA20;
        constexpr std::ptrdiff_t use = 0x205ECF0;
        constexpr std::ptrdiff_t zoom = 0x2315DF0;
    }
}
